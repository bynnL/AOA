-- sz = {10,30,50,233,311,125,341,23,43,66,38}
-- -- print(#sz)
-- -- print(sz[6])

-- -- sz[5] = 555

-- -- print(sz[5])
-- -- i = 1
-- -- j = 1

-- -- while i <(#sz) do
-- -- 	while j <= ((#sz)-i) do
-- -- 		if sz[j] < sz[j+1]  then
-- -- 			sz[j],sz[j+1] = sz[j+1],sz[j]
-- -- 		end
-- -- 		j=j+1
-- -- 	end
-- -- 	j=1
-- -- 	i=i+1
-- -- end
-- -- for k,v in pairs(sz) do
-- -- 	print(k.."键的值为"..v)
-- -- end


-- -- tm = {"j","h","g","f","s","r",}

-- -- shuchu = function()
-- -- 	for i = 1 ,#tm do
-- -- 		print(i..","..tm[i])
-- -- 	end
-- -- end

-- -- table.sort(tm)


-- -- shuchu()
-- package.path = /Users/aoa/desktop/12.lua

-- dofile = package



-- rawequal(1,2)

-- print(rawequal)
-- fofile(jiaoben.lua)

-- math.randomseed(os.time())
-- print(math.random(1,200))


-- a={22,55,66}

-- -- print(table.concat(a,"---",2,3))

-- -- table.insert(a,4,77)

-- -- print(a{1,2,3,4})

-- print(foreach(a,print))

-- t1 = "fuck666贵清"
-- t2 = 100
-- fuck = "fuck"
-- print(string.len(t1))
-- print(string.rep(t1,3))
-- print(string.lower(t1))
-- print(string.upper(t1))
-- print(string.sub(t1,8,13))
-- print(string.byte(t1,3))
-- print(string.char(t2))
-- print(string.gsub(t1,"贵清","channing"))
-- print(string.gsub(t1,"666","fuck陈贵清"))
-- print(string.find(t1,"贵清"))
-- print(string.format("我%s%s","fuck","贵清"))
-- print(string.format("我%02e%s%d%s",99,"贵清",100,"天"))

-- -- a = 
-- package.path = /Users/aoa/desktop/
-- print(os.rename(12.lua,13.lua))

-- t1 = os.time()
-- for i = 0,10000000 do 
-- 	i=i+1
-- end
-- t2 = os.time()
-- print(os.difftime(t2,t1))


-- -- print(os.date())

-- -- print(os.date("今天是%Y年%m月%d号星期%w的%X"))



-- -- temp = os.date("*t",os.time())
-- -- for k,v in pairs(temp) do
-- -- 	print(k,v)
-- -- end

-- -- io.read("*all")



-- -- io.write(...)


-- -- io.input("账号.txt")

-- -- io.read()


-- -- function fact(n)
-- -- 	if n==0 then
-- -- 		return 1
-- -- 	else
-- -- 	return n * fact(n-1)
-- -- end
-- -- end

-- -- print("enter a number:")
-- -- a=io.read("*number")

-- -- print(fact(a))

-- -- function norm(x,y)
-- -- 	return(x^2+y^2)^0.5
-- -- end
-- -- function twice(x)
-- -- 	return 2*x
-- -- end

-- -- --  and  break  do  else  elseif  end  false  for  
-- -- function id  in  local  nil  not  or   repeat  return then

-- -- 	true until while

-- -- "And"  "AND"

-- -- lua ["选项参数"]  脚本  参数    
-- --  -- lua  -e  "print("hello lua")"   
-- --  -l 加载库文件    -i 先执行完程序块再进入交互模式，  
-- -- lua -i  -l a -e "x=10"
-- -- -- 
-- -- -- _PROMPT 

-- a={}
-- k="x"
-- a[k]=10    -- key=x,value = 10

-- a[20] = "great"   -- key  20  ,value ="great"


-- a={}
-- a["x"]=10
-- b=a
-- print(b["x"])

-- return=b["x"]

-- a.name
-- a["x"]
-- a[x]

-- s={"20","21","103"}

-- function shuchu(s)

-- for k,v in ipairs(s) do

-- if v < #s then


-- end
-- end
-- end

-- print(shuchu(s))


-- d={12,20,30,50,20}

-- function maxnum(a)
-- 	local mi=1  --  表里最大的key
-- 	local m=a[mi]  -- 表里最大值
-- 	for i,val in ipairs(d) do
-- 		if val>m then
-- 			mi=i;m=val
-- 		end
-- 	end
-- 	return m,mi  --还回最大值的key和最大值
-- end
-- print(maxnum(d).."d")

-- function foo0(  )
-- end

-- function foo1()
-- 		return "a"
-- end

-- function foo2()
-- 	return "a","b"
-- end

-- -- -- x,y,z=foo2(),20  --调用的函数不是最后一个值时候，函数只还回第一个值
-- -- -- print(x,y,z)

-- -- -- print(foo0())
-- -- -- print(foo1())
-- -- -- print(foo2())
-- -- -- print(foo2(),1)
-- -- print(foo2().."x")
-- -- print("a","b")

-- a={10,20,30}

-- t={foo2()}
-- print(t[1],t[2])


--print(unpack {10,20,30})

--a,b=unpack(10,20)
-- a={10,20}
-- -- f(unpack(a))
-- -- f=string.find
-- -- a={"hello","11"}

-- -- print(string.find(unpack(a)))
-- function add( ... )
-- 	local s=0
-- 	for i,v in ipairs{...} do
-- 		s=s+v
-- 	end
-- 		return s
-- end
-- print("请输出一个数字：")

-- -- print(add(1,3,5,7,9,6^6))

-- local f=io.open("3.txt","a+")
-- f:write("Happy New Year!")
-- f:flush()
-- f:seek("end",-1) --定位到文件末尾前一个字节
-- local str=f:read(1) --读取一个字符
-- print(str) --输出"!"
-- f:close()

-- local fiel_path="/Users/aoa/desktop/a1.txt"
-- local file = io.open(fiel_path,"r")
-- local ret = file:read("*all")
-- io.write(ret,",123")


-- file:close()

-- ret1={"asdf","sdfsdf"}

-- for k,v in pairs(ret1) do
-- 	print(k,v)
-- end
-- local fact

-- fact =function(n)
-- 	if n==0 then
-- 		return 1
-- 	else
-- 		return n*fact(n-1)
-- 	end
-- end
-- print(fact(10))

-- local function foo()(函数)
-- 	local foo
-- 	foo=function()()end


-- local function facdt(n)
-- 	if n==0 then
-- 		return 1
-- 	else
-- 		return n*fact(n-1)
-- 	end
-- end
-- print(fact(5))
-- function g()
-- end

-- function f (x)
-- 	print("hahahah")
-- 	return g(x)
-- end


-- function room1()
-- 	local move=io.read()
-- 	if move=="south"  then  
-- 		return room3()
-- 	elseif move=="east" then
-- 		return room2()
-- 	else
-- 		print("invalid move")
-- 		return room1()
-- 	end
-- end

-- function room2()
-- 	local move=io.read()
-- 	if move =="south" then
-- 		return room4()
-- 	elseif move=="west" then
-- 		return room1()
-- 	else 
-- 		print("invalid move")
-- 		return room2()
-- 	end
-- end

-- function room3()
-- 	local move=io.read()
-- 	if move=="north" then
-- 		return room1()
-- 	elseif move=="east" then
-- 		return room4()
-- 	else 
-- 		print("invalid move")
-- 		return room3()
-- 	end
-- end

-- function room4()
-- 	print("congtatulations!")
-- end

-- function values(t)
-- 	local i=0
-- 	return function()
-- 		i=i+1
-- 		return t[i]
-- 	end
-- end
----------------------
-- t={10,20,30}
-- iter=values(t)
-- while true do
-- 	local element=iter()
-- 	if element==nil then
-- 		break
-- 	end
-- 	print(element)
-- end
-------------------------------
-- t={10,20,30}
-- for element in values(t) do
-- 	print(element)
-- end
-------------------------------
-- for word in allwords() do
-- 	print(word)
-- end
-------------------------------
-- function allwords()
-- 	local line = io.read() --当前行
-- 	local pos=1 --一行中的位置
-- 	return function()   -- 迭代器函数
-- 		while line do   -- 惹为有效的行内容就进入循环行

-- 			local s,e=string.find(line,"%w+",pos)  --"hello,word" string.find("hello word","%w+",1)--1,5

-- 			if s then --是否找到一个单词
-- 				pos=e+1  -- 该单词的下一个位置
-- 				return string.sub(line,s,e)   --返回该单词
-- 			else
-- 				line=io.read() --没有找到单词，就尝试读下一行
-- 				pos=1
-- 			end
-- 				return nil -- 没有剩余行了，遍历结束
-- 		end
-- 	end
-- end
-------------------------------
-- for(var-list) in (exp-list) do
-- 	(body)
-- end
-------------------------------
-- for k,v in pairs(t) do  --只有一个
-- 	print(k,v)
-- end
-- -------------------------------

-- for line in io.lines() do
-- 	io.write(line,"\n")
-- end
-- -------------------------------
-- for var_1,...,var_n in (exp-list)  do
-- 	(block)
-- end
-- --等于下面
-- do
-- 	local _f,_s,_var=(exp-list)
-- 	while true do
-- 		local var_1,...,var_n = _f(_s,_var)
-- 			_var=var_1
-- 			if  _var==nil then
-- 				break
-- 			end
-- 		(block)
-- 	end
-- end
-------------------------------
-- local iterator

-- function allwords()
-- 	local state={line=io.read(),pos=1}
-- 	return iterator,state
-- end
-- function iterator(state)
-- 	while state.line do   --惹为有效的行就进入循环
-- 	--搜索下一个单词
-- 		local s,e=string.find(state.line,"%w+",state.pos)
-- 			if s then  --如果找到一个单词
-- 			state.pos=e+1
-- 			return string.sub(state.line,s,e)
-- 		else   --没有找到单词

-- 			state.line=io.read()  --尝试下一行
-- 			state.pos=1

-- 		end
--     end
--     return nil
-- end

-- for word in allwords() do
-- 	print(word)
-- end

-- word="i am astudent"
-- -- -------------------------------

-- i=0
-- f=loadstring("i=i+1")
-- f();print(i)
-------------------------------
i = 32
local i = 0
f = loadstring("i=i+1;print(i)")
g = function() i=i+1; print(i) end
f()




























