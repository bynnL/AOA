-- for i = 1,16,2 do
-- 	if i == 11 then
-- 		break
-- 	end
-- 	print("循环了几次？"..i)
-- end


-- for i = 1,4,1 do
-- 	for j = 1,4,1 do
-- 		for p = 1,4,1 do
-- 			if i ~= j and i ~= p and j ~= p then
-- 				print(i..j..p)
-- 			end
-- 		end
-- 	end
-- end


function fb(i)
	if i <= 2 and i > 0 then
		

