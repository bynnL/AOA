function foo(x)
	print(5+5)
end