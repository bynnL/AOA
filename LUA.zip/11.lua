function test(n)
	local i = 1
	if n < 0 then
		n = 1
	end
	repeat
		i = n * i
		n = n - 1
	until n == 0
	print(i)
end
print(test(6))




