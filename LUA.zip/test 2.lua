-- sz = {10,30,50,233,311,125,341,23,43,66,38}
-- -- print(#sz)
-- -- print(sz[6])

-- -- sz[5] = 555

-- -- print(sz[5])
-- -- i = 1
-- -- j = 1

-- -- while i <(#sz) do
-- -- 	while j <= ((#sz)-i) do
-- -- 		if sz[j] < sz[j+1]  then
-- -- 			sz[j],sz[j+1] = sz[j+1],sz[j]
-- -- 		end
-- -- 		j=j+1
-- -- 	end
-- -- 	j=1
-- -- 	i=i+1
-- -- end
-- -- for k,v in pairs(sz) do
-- -- 	print(k.."键的值为"..v)
-- -- end


-- -- tm = {"j","h","g","f","s","r",}

-- -- shuchu = function()
-- -- 	for i = 1 ,#tm do
-- -- 		print(i..","..tm[i])
-- -- 	end
-- -- end

-- -- table.sort(tm)


-- -- shuchu()
-- package.path = /Users/aoa/desktop/12.lua

-- dofile = package



-- rawequal(1,2)

-- print(rawequal)
-- fofile(jiaoben.lua)

-- math.randomseed(os.time())
-- print(math.random(1,200))


-- a={22,55,66}

-- -- print(table.concat(a,"---",2,3))

-- -- table.insert(a,4,77)

-- -- print(a{1,2,3,4})

-- print(foreach(a,print))

-- t1 = "fuck666贵清"
-- t2 = 100
-- fuck = "fuck"
-- print(string.len(t1))
-- print(string.rep(t1,3))
-- print(string.lower(t1))
-- print(string.upper(t1))
-- print(string.sub(t1,8,13))
-- print(string.byte(t1,3))
-- print(string.char(t2))
-- print(string.gsub(t1,"贵清","channing"))
-- print(string.gsub(t1,"666","fuck陈贵清"))
-- print(string.find(t1,"贵清"))
-- print(string.format("我%s%s","fuck","贵清"))
-- print(string.format("我%02e%s%d%s",99,"贵清",100,"天"))

-- -- a = 
-- package.path = /Users/aoa/desktop/
-- print(os.rename(12.lua,13.lua))

-- t1 = os.time()
-- for i = 0,10000000 do 
-- 	i=i+1
-- end
-- t2 = os.time()
-- print(os.difftime(t2,t1))


-- print(os.date())

-- print(os.date("今天是%Y年%m月%d号星期%w的%X"))



-- temp = os.date("*t",os.time())
-- for k,v in pairs(temp) do
-- 	print(k,v)
-- end

-- io.read("*all")



-- io.write(...)


-- io.input("账号.txt")

-- io.read()


-- function fact(n)
-- 	if n==0 then
-- 		return 1
-- 	else
-- 	return n * fact(n-1)
-- end
-- end

-- print("enter a number:")
-- a=io.read("*number")

-- print(fact(a))

function norm(x,y)
	return(x^2+y^2)^0.5
end
function twice(x)
	return 2*x
end





























