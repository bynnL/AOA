data="aasdajoijlsknhv"
print(data.encode(data).hex())